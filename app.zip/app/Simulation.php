<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Simulation extends Model
{
    //
}
